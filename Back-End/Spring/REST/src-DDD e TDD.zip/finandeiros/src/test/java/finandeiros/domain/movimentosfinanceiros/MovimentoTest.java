package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.ContaBancaria;
import finandeiros.domain.contas.ContaFixaMensal;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsNull.notNullValue;

public class MovimentoTest {

    private static final String DESCRICAO = "pagamento de conta de luz";
    private Movimento movimento;

    @Before
    public void setup() {
        AgregadorContas agregadorContas = new AgregadorContas(new ContaBancaria("Conta Bradesco"),
                new ContaFixaMensal("Luz", 15));
        this.movimento = new Movimento(agregadorContas, new DateTime(2015, 6, 11, 15, 20).toDate(), DESCRICAO);
    }

    @Test
    public void deveTerContaCredito() {
        assertThat(movimento.contaCredito(), notNullValue());
    }

    @Test
    public void deveTerContaDebito() {
        assertThat(movimento.contaDebito(), notNullValue());
    }

    @Test
    public void deveTerData() {
        assertThat(movimento.data(), notNullValue());
    }

    @Test
    public void deveTerDescricao() {
        assertThat(movimento.descricao(), notNullValue());
    }

    @Test
    public void deveRealizarMovimentoIgnorandoSinalNegativo() {
        movimento.realizar(-1500.0);
        assertThat(movimento.credito(), equalTo(1500.0));
    }

    @Test
    public void deveRealizarMovimentoIgnorandoSinalPositivo() {
        movimento.realizar(1200.0);
        assertThat(movimento.debito(), equalTo(-1200.0));
    }

}
