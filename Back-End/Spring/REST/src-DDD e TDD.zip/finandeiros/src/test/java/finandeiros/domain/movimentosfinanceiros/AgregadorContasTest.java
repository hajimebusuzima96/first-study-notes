package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.ContaBancaria;
import finandeiros.domain.contas.ContaFixaMensal;
import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;

public class AgregadorContasTest {

    private AgregadorContas agregadorContas;

    @Before
    public void setup() {
        this.agregadorContas = new AgregadorContas(new ContaBancaria("Conta Bradesco"), new ContaFixaMensal("Luz", 15));
    }

    @Test
    public void deveTerContaCredito() {
        assertThat(agregadorContas.credito(), instanceOf(Creditavel.class));
    }

    @Test
    public void deveTerContaDebito() {
        assertThat(agregadorContas.debito(), instanceOf(Debitavel.class));
    }

}
