package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.ContaBancaria;
import finandeiros.domain.contas.ContaFixaMensal;
import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsNull.notNullValue;

public class MovimentosTest {

    private Movimentos repositorio;

    @Before
    public void setup() {
        repositorio = new MovimentosStub();
    }

    @Test
    public void deveSalvarMovimentosNovos() {
        Debitavel contaDebito  = new ContaBancaria("Bradesco");
        Creditavel contaCredito = new ContaFixaMensal("Luz", 15);
        Date data = new DateTime(2015, 7, 11, 0, 0).toDate();
        String descricao = "pagamento conta luz de julho";
        Movimento movimento = new MovimentoBuilder().comContaDebito(contaDebito).eContaCredito(contaCredito)
                .eData(data).eDescricao(descricao).build();

        repositorio.salvar(movimento);
        assertThat(movimento.getId(), notNullValue());
    }

    @Test
    public void deveObterMovimentosPorPeriodo() {
        Date inicio = new DateTime(2015, 1, 1, 0, 0).toDate();
        Date fim = new DateTime(2015, 6, 30, 0, 0).toDate();
        List<Movimento> movimentosPorPeriodo = repositorio.todosPorPeriodo(inicio, fim);
        assertThat(movimentosPorPeriodo.size(), equalTo(5));
    }

}
