package finandeiros.domain.contas;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

public class ContaBancariaTest {

    private static final String NOME_CONTA = "Minha conta Bradesco";
    private ContaBancaria conta;

    @Before
    public void setup() {
        this.conta = new ContaBancaria(NOME_CONTA);
    }

    @Test
    public void deveTerUmNome() {
        assertThat(conta.nome(), equalTo(NOME_CONTA));
    }

    @Test
    public void deveSerUmaContaDebitavel() {
        assertThat(conta, instanceOf(Debitavel.class));
    }

    @Test
    public void deveSerUmaContaCreditavel() {
        assertThat(conta, instanceOf(Creditavel.class));
    }

}
