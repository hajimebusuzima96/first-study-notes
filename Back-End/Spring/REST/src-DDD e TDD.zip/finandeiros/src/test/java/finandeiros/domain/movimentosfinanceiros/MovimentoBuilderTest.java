package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.ContaBancaria;
import finandeiros.domain.contas.ContaFixaMensal;
import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;

import java.util.Date;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsNull.notNullValue;

public class MovimentoBuilderTest {

    private Debitavel contaDebito = new ContaBancaria("Bradesco");
    private Creditavel contaCredito = new ContaFixaMensal("Luz", 15);
    private Date data = new DateTime(2015, 7, 11, 0, 0).toDate();
    private String descricao = "pagamento conta luz de julho";
    private Movimento movimento;

    @Before
    public void setup() {
        MovimentoBuilder movimentoBuilder = new MovimentoBuilder();
        this.movimento = movimentoBuilder.comContaDebito(contaDebito).eContaCredito(contaCredito)
                .eData(data).eDescricao(descricao).build();
    }

    @Test
    public void deveCriarMovimento() {
        assertThat(movimento, notNullValue());
    }

    @Test
    public void deveCriarMovimentoComContaCredito() {
        assertThat(movimento.contaCredito(), equalTo(contaCredito));
    }

    @Test
    public void deveCriarMovimentoComContaDebito() {
        assertThat(movimento.contaDebito(), equalTo(contaDebito));
    }

    @Test
    public void deveCriarMovimentoComData() {
        assertThat(movimento.data(), equalTo(data));
    }

    @Test
    public void deveCriarMovimentoComDescricao() {
        assertThat(movimento.descricao(), equalTo(descricao));
    }

}
