package finandeiros.domain.contas;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

public class ContaFixaMensalTest {

    private static final String DESCRICAO = "Luz";
    private static final int DIA_VENCIMENTO = 15;
    private ContaFixaMensal conta;

    @Before
    public void setup() {
        this.conta = new ContaFixaMensal(DESCRICAO, DIA_VENCIMENTO);
    }

    @Test
    public void deveTerDescricao() {
        assertThat(conta.descricao(), equalTo(DESCRICAO));
    }

    @Test
    public void deveTerDataDeVencimento() {
        assertThat(conta.diaVencimento(), equalTo(DIA_VENCIMENTO));
    }

}
