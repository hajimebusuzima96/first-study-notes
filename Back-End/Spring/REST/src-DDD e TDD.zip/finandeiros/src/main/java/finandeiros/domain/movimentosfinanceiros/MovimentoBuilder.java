package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;

import java.util.Date;

public class MovimentoBuilder {

    private Debitavel contaDebito;
    private Creditavel contaCredito;
    private Date data;
    private String descricao;

    public MovimentoBuilder comContaDebito(Debitavel contaDebito) {
        this.contaDebito = contaDebito;
        return this;
    }

    public MovimentoBuilder eContaCredito(Creditavel contaCredito) {
        this.contaCredito = contaCredito;
        return this;
    }

    public MovimentoBuilder eData(Date data) {
        this.data = data;
        return this;
    }

    public MovimentoBuilder eDescricao(String descricao) {
        this.descricao = descricao;
        return this;
    }

    public Movimento build() {
        AgregadorContas agregadorContas = new AgregadorContas(contaDebito, contaCredito);
        return new Movimento(agregadorContas, data, descricao);
    }
}
