package finandeiros.domain.movimentosfinanceiros;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MovimentosStub extends Movimentos {

    private List<Movimento> stubList = new ArrayList<Movimento>();

    public MovimentosStub() {
        createStub();
    }

    private void createStub() {
        MovimentoBuilder builder = new MovimentoBuilder();
        for (int i = 0; i < 5; i++) {
            stubList.add(builder.build());
        }
    }

    @Override
    public void salvar(Movimento movimento) {
        movimento.setId(1L);
    }

    @Override
    public List<Movimento> todosPorPeriodo(Date inicio, Date fim) {
        return stubList;
    }
}
