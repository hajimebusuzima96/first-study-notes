package finandeiros.domain.contas;

public class ContaBancaria implements Creditavel, Debitavel {

    private String nomeConta;

    public ContaBancaria(String nomeConta) {
        this.nomeConta = nomeConta;
    }

    public String nome() {
        return nomeConta;
    }

}
