package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.ContaBancaria;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Movimentos {

    public void salvar(Movimento movimento) {
        throw new NotImplementedException();
    }

    public List<Movimento> todosPorPeriodo(Date inicio, Date fim) {
        throw new NotImplementedException();
    }
}
