package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;

import java.util.Date;

class Movimento {
    private Long id;
    private AgregadorContas agregadorContas;
    private final Date data;
    private final String descricao;
    private double valor;

    Movimento(AgregadorContas agregadorContas, Date data, String descricao) {
        this.agregadorContas = agregadorContas;
        this.data = data;
        this.descricao = descricao;
    }

    public void realizar(double valor) {
        this.valor = Math.abs(valor);
    }

    public double credito() {
        return valor;
    }

    public double debito() {
        return -valor;
    }

    public Date data() {
        return data;
    }

    public Debitavel contaDebito() {
        return agregadorContas.debito();
    }

    public Creditavel contaCredito() {
        return agregadorContas.credito();
    }

    public String descricao() {
        return descricao;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }


}
