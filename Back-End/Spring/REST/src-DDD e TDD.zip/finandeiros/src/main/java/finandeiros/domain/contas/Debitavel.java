package finandeiros.domain.contas;

public interface Debitavel {
}
