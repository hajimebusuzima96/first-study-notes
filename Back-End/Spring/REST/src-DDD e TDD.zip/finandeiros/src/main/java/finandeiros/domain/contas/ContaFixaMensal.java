package finandeiros.domain.contas;

public class ContaFixaMensal implements Creditavel {

    private final String descricao;
    private final int diaVencimento;

    public ContaFixaMensal(String descricao, int diaVencimento) {
        this.descricao = descricao;
        this.diaVencimento = diaVencimento;
    }

    public String descricao() {
        return descricao;
    }

    public int diaVencimento() {
        return diaVencimento;
    }
}
