package finandeiros.domain.movimentosfinanceiros;

import finandeiros.domain.contas.Creditavel;
import finandeiros.domain.contas.Debitavel;

public class AgregadorContas {

    private final Debitavel contaDebito;
    private final Creditavel contaCredito;

    public AgregadorContas(Debitavel contaDebito, Creditavel contaCredito) {
        this.contaDebito = contaDebito;
        this.contaCredito = contaCredito;
    }

    public Creditavel credito() {
        return contaCredito;
    }

    public Debitavel debito() {
        return contaDebito;
    }

}
