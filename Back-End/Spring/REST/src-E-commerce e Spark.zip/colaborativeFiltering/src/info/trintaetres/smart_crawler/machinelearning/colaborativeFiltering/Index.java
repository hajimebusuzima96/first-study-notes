package info.trintaetres.smart_crawler.machinelearning.colaborativeFiltering;

import info.trintaetres.smart_crawler.indexer.GeneralElasticsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.spark.mllib.recommendation.Rating;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.action.get.GetRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.MatchAllQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;

public class Index {

	private static Client client;

	public static synchronized Client getClient() throws Exception {

		if (client == null) {
			TransportClient transportClient;

			Settings settings = ImmutableSettings.settingsBuilder()
					.put("cluster.name", "ecommerce").build();
			transportClient = new TransportClient(settings);
			client = transportClient
					.addTransportAddress(new InetSocketTransportAddress(
							"localhost", 9200));
		}

		return client;
	}

	public String getProduto(int id) {
		GetRequestBuilder request = client.prepareGet().setIndex("ecommerce")
				.setType("produto").setId(String.valueOf(id));

		return request.get().getSource().get("nome").toString();
	}

	public String getUser(int id) throws Exception {
		GetRequestBuilder request = client.prepareGet().setIndex("ecommerce")
				.setType("user").setId(String.valueOf(id));

		return request.get().getSource().get("nome").toString();

	}

	public List<Rating> getRatings() throws ElasticsearchException, Exception {

		MatchAllQueryBuilder qb = QueryBuilders.matchAllQuery();

		Set<SearchHit> hits = query(qb, 0, 1000);

		List<Rating> ratings = new ArrayList<Rating>();

		for (SearchHit hit : hits) {

			ratings.add(new Rating(Integer.valueOf(hit.getSource().get("user")
					.toString()), Integer.valueOf(hit.getSource()
					.get("product").toString()), Double.valueOf(hit.getSource()
					.get("rating").toString())));

		}

		return ratings;
	}

	private Set<SearchHit> query(QueryBuilder qb, int from, int size)
			throws ElasticsearchException, Exception {
		SearchResponse scrollResp = GeneralElasticsearch.getClient()
				.prepareSearch("ecommerce").setSearchType(SearchType.SCAN)
				.setScroll(new TimeValue(60000)).setQuery(qb).setFrom(from)
				.setSize(size).execute().actionGet();

		Set<SearchHit> response = new HashSet<SearchHit>();

		while (true) {
			response.addAll(Arrays.asList(scrollResp.getHits().getHits()));

			scrollResp = GeneralElasticsearch.getClient()
					.prepareSearchScroll(scrollResp.getScrollId())
					.setScroll(new TimeValue(600000)).execute().actionGet();

			if (scrollResp.getHits().getHits().length == 0) {
				break;
			}

		}

		return response;
	}
}
