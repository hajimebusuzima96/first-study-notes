package info.trintaetres.smart_crawler.machinelearning.colaborativeFiltering;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaDoubleRDD;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.mllib.classification.NaiveBayesModel;
import org.apache.spark.mllib.recommendation.ALS;
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel;
import org.apache.spark.mllib.recommendation.Rating;
import org.apache.spark.mllib.regression.LabeledPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.Tuple2;

public class CFImpl implements Serializable {
	
	private static final long serialVersionUID = 5209690473689123129L;

	private static final Logger logger = LoggerFactory
			.getLogger(CFImpl.class);
	
	private static SparkConf conf;
	private static JavaSparkContext sc;
	private  MatrixFactorizationModel model;
	
	public void startClassficication(String [] model){

		conf = new SparkConf().setAppName("Colaborative Filtering")
				.setMaster("spark://luiz-System-Product-Name:7077")
				.setJars(new String[]{"target/smart-crawler-0.0.1-SNAPSHOT.jar"})
				.set("spark.akka.frameSize", "20");
		
		sc = new JavaSparkContext(conf);
	}
	
	public void treinar(JavaRDD<String> rawData) {

	    JavaRDD<Rating> ratings = rawData.map(
	      new Function<String, Rating>() {
	        public Rating call(String s) {
	          String[] sarray = s.split(",");
	          return new Rating(Integer.parseInt(sarray[0]), Integer.parseInt(sarray[1]), 
	                            Double.parseDouble(sarray[2]));
	        }
	      }
	    );

		logger.info("Mean Squared Error = " + avaliar(ratings));
	    
	    // Build the recommendation model using ALS
	    int rank = 10;
	    int numIterations = 20;
	    MatrixFactorizationModel model = ALS.train(JavaRDD.toRDD(ratings), rank, numIterations, 0.01); 

	    // Save and load model
	    model = MatrixFactorizationModel.load(sc.sc(), "myModelPath");
	    
		sc.close();
	}
	
	public double avaliar(JavaRDD<Rating> ratings){

	    // Evaluate the model on rating data
	    JavaRDD<Tuple2<Object, Object>> userProducts = ratings.map(
	      new Function<Rating, Tuple2<Object, Object>>() {
	        public Tuple2<Object, Object> call(Rating r) {
	          return new Tuple2<Object, Object>(r.user(), r.product());
	        }
	      }
	    );
	    JavaPairRDD<Tuple2<Integer, Integer>, Double> predictions = JavaPairRDD.fromJavaRDD(
	      model.predict(JavaRDD.toRDD(userProducts)).toJavaRDD().map(
	        new Function<Rating, Tuple2<Tuple2<Integer, Integer>, Double>>() {
	          public Tuple2<Tuple2<Integer, Integer>, Double> call(Rating r){
	            return new Tuple2<Tuple2<Integer, Integer>, Double>(
	              new Tuple2<Integer, Integer>(r.user(), r.product()), r.rating());
	          }
	        }
	    ));
	    JavaRDD<Tuple2<Double, Double>> ratesAndPreds = 
	      JavaPairRDD.fromJavaRDD(ratings.map(
	        new Function<Rating, Tuple2<Tuple2<Integer, Integer>, Double>>() {
	          public Tuple2<Tuple2<Integer, Integer>, Double> call(Rating r){
	            return new Tuple2<Tuple2<Integer, Integer>, Double>(
	              new Tuple2<Integer, Integer>(r.user(), r.product()), r.rating());
	          }
	        }
	    )).join(predictions).values();
	    
	    double MSE = JavaDoubleRDD.fromRDD(ratesAndPreds.map(
	      new Function<Tuple2<Double, Double>, Object>() {
	        public Object call(Tuple2<Double, Double> pair) {
	          Double err = pair._1() - pair._2();
	          return err * err;
	        }
	      }
	    ).rdd()).mean();
	    
	    return MSE;
	}
	
	public void recomendarProduto(int usuario){
		Index index = new Index();
		Rating[] ratings = model.recommendProducts(usuario, 10);
		
		for(Rating rating: ratings){
			index.getProduto(rating.product());
			logger.info(String.valueOf(rating.rating()));
		}
	}
	
	public void recomendarUsuarios (int produto) throws Exception{
		Index index = new Index();
		Rating[] ratings = model.recommendUsers(produto, 10);
		
		for(Rating rating: ratings){
			index.getUser(rating.user());
			logger.info(String.valueOf(rating.rating()));
		}
	}

}
