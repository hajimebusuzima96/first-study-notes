package br.com.javamagazine.service;

import java.util.List;

import br.com.javamagazine.model.Autorizacao;

public interface AutorizacaoService {
	
	public Autorizacao salvar(Autorizacao autorizacao);
	
	public void excluir(Long id);
	
	public Autorizacao pesquisarPorId(Long id);
	
	public List<Autorizacao> pesquisarPorNome(String nome);
	
	public List<Autorizacao> todos();

}
