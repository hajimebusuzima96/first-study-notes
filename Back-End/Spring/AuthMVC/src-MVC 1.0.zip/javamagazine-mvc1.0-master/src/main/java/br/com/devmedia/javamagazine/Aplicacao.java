package br.com.devmedia.javamagazine;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("web")
public class Aplicacao extends Application {
}